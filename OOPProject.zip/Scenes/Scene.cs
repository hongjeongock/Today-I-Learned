﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _20260107.Scenes
{
    public abstract class Scene // 상태를 객체화 하자
    {
        public abstract void Enter();
        public abstract void Update();
        public abstract void Render();

        public abstract void Exit();

    }
}
