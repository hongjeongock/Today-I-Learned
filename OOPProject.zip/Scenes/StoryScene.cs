﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _20260107.Scenes
{
    public class StoryScene : Scene
    {
        public override void Enter()
        {
            
        }

        public override void Update()
        {
            
        }
        public override void Render()
        {
            
        }
        public override void Exit()
        {
            
        }
    }
}
