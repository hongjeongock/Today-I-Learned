﻿using _20260107.GameObject;

public class PlayerCharacter : GameObject
{
    public PlayerCharacter() => Init();
    public Tile[,] Field { get; set; }

    public void Init()
    {
        Symbol = 'P';
    }

    public void Update()
    {
        Vector direction = new Vector();

        if (InputManager.GetKey(ConsoleKey.UpArrow))
            direction = Vector.Up;

        if (InputManager.GetKey(ConsoleKey.DownArrow))
            direction = Vector.Down;

        if (InputManager.GetKey(ConsoleKey.LeftArrow))
            direction = Vector.Left;

        if (InputManager.GetKey(ConsoleKey.RightArrow))
            direction = Vector.Right;

        if (Field != null) Move(direction);
    }

    private void Move(Vector direction)
    {
        Vector nextPos = Position + direction;

        // 1. 맵 바깥은 아닌지?
        // 2. 벽인지?

        Field[Position.Y, Position.X].OnTileObject = null;
        Field[nextPos.Y, nextPos.X].OnTileObject = this;
        Position = nextPos;
    }
}